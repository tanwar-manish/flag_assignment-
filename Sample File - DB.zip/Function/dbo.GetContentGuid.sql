/*DBTYPE:SQLSERVER|TARGETDB:HPFSIDS*/
IF EXISTS(SELECT * FROM Information_schema.Routines WHERE Specific_schema = 'DBO' AND specific_name = 'GetContentGuid' AND Routine_Type = 'FUNCTION') 
	BEGIN 
		DROP FUNCTION dbo.GetContentGuid
	END
GO

CREATE FUNCTION dbo.GetContentGuid(@ContentBinary VARBINARY(MAX))  
RETURNS UNIQUEIDENTIFIER  
AS   
BEGIN  
DECLARE @ContentGUID NVARCHAR(50)  
                SET @ContentGUID = CONVERT(NVARCHAR(50), @ContentBinary)              
  
                RETURN CONVERT(UNIQUEIDENTIFIER, SUBSTRING(@ContentGUID, CHARINDEX(':', @ContentGUID,0) + 1, 36)
)  
END;
GO

GRANT SELECT ON dbo.GetContentGuid TO DMUsr01;
GO